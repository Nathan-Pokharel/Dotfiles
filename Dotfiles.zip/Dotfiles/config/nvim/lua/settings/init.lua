local set = vim.opt
set.relativenumber=true
set.expandtab = true
set.smarttab=true
set.hlsearch=false
set.shiftwidth=4
set.tabstop =4 
set.hlsearch=true
set.incsearch=true
set.ignorecase=true
set.smartcase=true

set.splitright=true
set.fileencoding = 'utf-8'
set.termguicolors=true
set.number=true
set.cursorline=true

set.hidden=true

