local map =vim.api.nvim_set_keymap 

vim.g.mapleader=' '
local opts= {noremap=true,silent=true}
map('n','<C-t>' , ':tabnew<CR><i>',opts)
map('n','<C-q>',':bdelete!<CR>',opts)
map('n','<C-Right>',':BufferNext<CR>',opts)
map('n','<C-Left>',':BufferPrev<CR>',opts)
map('n','<C-p>',':FZF<CR>',opts)
map('n','<C-f>','/',opts)
map('n','<C-s>',':w<CR><i>',opts)
map('n','<C-j>','<cmd>lua vim.diagnostic.goto_next()<CR>',opts)
map('n','<C-k>','<cmd>lua vim.diagnostic.goto_prev()<CR>',opts)
map('i','<C-s>','<ESC>:w<CR><i>',opts)

