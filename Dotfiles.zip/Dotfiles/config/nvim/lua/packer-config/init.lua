return require 'packer'.startup(function()
    use "kyazdani42/nvim-web-devicons"
    use 'wbthomason/packer.nvim'
    use "rose-pine/neovim"
    use "SirVer/ultisnips"
    use {'romgrk/barbar.nvim',requires = {'kyazdani42/nvim-web-devicons'}}
    use "neovim/nvim-lspconfig"
    use "lukas-reineke/indent-blankline.nvim"
    use 'vim-scripts/AutoComplPop'
    use {"windwp/nvim-autopairs",config = function() require("nvim-autopairs").setup {} end}
    use 'nvim-treesitter/nvim-treesitter'
end)
