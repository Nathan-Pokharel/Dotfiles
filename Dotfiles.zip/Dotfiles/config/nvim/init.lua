--vim.o.runtimepath = vim.fn.stdpath('data') .. '/site/pack/*/start/*,' .. vim.o.runtimepath
require("barbar-config")
require('autopairs-config')
require ('settings')
require ('nvimlsp-config')
require ('packer-config')
require('mappings')
require('treesitter-config')
vim.o.swapfile = false
vim.cmd('colorscheme rose-pine')
vim.cmd('set laststatus=0')
vim.cmd("let g:UltiSnipsExpandTrigger= '<tab>' ")
vim.cmd("let g:UltiSnipsJumpForwardTrigger='<tab>'")
vim.cmd("let g:UltiSnipsJumpBackwardTrigger='<c-j>'")
local signs = { Error = " ", Warn = " ", Hint = " ", Info = " " }
for type, icon in pairs(signs) do
  local hl = "DiagnosticSign" .. type
  vim.fn.sign_define(hl, { text = icon, texthl = hl, numhl = hl })
end
